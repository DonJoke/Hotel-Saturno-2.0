from django.db import models
#vamos a tener 3 modelos,cliente,habitacion y reserva :D 

#proximamente vamos a implementar un import "from rut_validator import validate_rut" que valida rut
#solo numeros,con puntos y guion,sin puntos y guion pero que se activa mediante un pip mediante la shell.

class cliente(models.Model)
    Nombre = models.CharField(max_length = 100)
    NumeroVerificador = models.CharField(1)
    Rut = models.IntegerField()
    Telefono = models.IntegerField()
    Correo = models.CharField()

def __str___(self):
    return self.Nombre

class habitacion(models.Model)
    NumeroHabitacion = 
    Piso =
    TipoDeHabitacion =


class reserva(models.Model)
    
